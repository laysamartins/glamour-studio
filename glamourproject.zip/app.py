import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash
from database import conectar, inicializar_banco

app = Flask(__name__)
app.secret_key = "glamour_chave_secreta"

inicializar_banco()

@app.route("/")
def inicio():
    conexao = conectar()

    total_clientes = conexao.execute(
        "SELECT COUNT(*) FROM clientes"
    ).fetchone()[0]

    total_servicos = conexao.execute(
        "SELECT COUNT(*) FROM servicos"
    ).fetchone()[0]

    total_agendamentos = conexao.execute(
        "SELECT COUNT(*) FROM agendamentos"
    ).fetchone()[0]

    proximos = conexao.execute("""
        SELECT
            agendamentos.id,
            clientes.nome AS cliente,
            servicos.nome AS servico,
            agendamentos.data,
            agendamentos.horario
        FROM agendamentos
        JOIN clientes ON clientes.id = agendamentos.cliente_id
        JOIN servicos ON servicos.id = agendamentos.servico_id
        WHERE agendamentos.data >= date('now', 'localtime')
        ORDER BY agendamentos.data, agendamentos.horario
        LIMIT 5
    """).fetchall()

    conexao.close()

    return render_template(
        "index.html",
        total_clientes=total_clientes,
        total_servicos=total_servicos,
        total_agendamentos=total_agendamentos,
        proximos=proximos
    )

@app.route("/clientes", methods=["GET", "POST"])
def clientes():
    conexao = conectar()

    if request.method == "POST":
        nome = request.form["nome"].strip()
        telefone = request.form["telefone"].strip()
        email = request.form.get("email", "").strip()

        if not nome or not telefone:
            flash("Preencha o nome e o telefone.")
        else:
            conexao.execute("""
                INSERT INTO clientes (nome, telefone, email)
                VALUES (?, ?, ?)
            """, (nome, telefone, email))

            conexao.commit()
            flash("Cliente cadastrado com sucesso!")

        conexao.close()
        return redirect(url_for("clientes"))

    lista_clientes = conexao.execute(
        "SELECT * FROM clientes ORDER BY nome"
    ).fetchall()

    conexao.close()

    return render_template(
        "clientes.html",
        clientes=lista_clientes
    )

@app.route("/clientes/excluir/<int:id>", methods=["POST"])
def excluir_cliente(id):
    conexao = conectar()

    try:
        conexao.execute(
            "DELETE FROM clientes WHERE id = ?", (id,)
        )
        conexao.commit()
        flash("Cliente excluído com sucesso!")
    except Exception:
        conexao.rollback()
        flash("Não foi possível excluir. O cliente possui agendamentos.")

    conexao.close()

    return redirect(url_for("clientes"))

@app.route("/servicos", methods=["GET", "POST"])
def servicos():
    conexao = conectar()

    if request.method == "POST":
        nome = request.form["nome"].strip()

        try:
            preco = float(request.form["preco"])
            duracao = int(request.form["duracao"])

            if not nome or preco < 0 or duracao <= 0:
                raise ValueError

            conexao.execute("""
                INSERT INTO servicos (nome, preco, duracao)
                VALUES (?, ?, ?)
            """, (nome, preco, duracao))

            conexao.commit()
            flash("Serviço cadastrado com sucesso!")

        except ValueError:
            flash("Verifique os dados do serviço.")

        conexao.close()
        return redirect(url_for("servicos"))

    lista_servicos = conexao.execute(
        "SELECT * FROM servicos ORDER BY nome"
    ).fetchall()

    conexao.close()

    return render_template(
        "servicos.html",
        servicos=lista_servicos
    )


@app.route("/agendamentos", methods=["GET", "POST"])
def agendamentos():
    conexao = conectar()

    if request.method == "POST":
        cliente_id = request.form["cliente_id"]
        servico_id = request.form["servico_id"]
        data = request.form["data"]
        horario = request.form["horario"]

        try:
            conexao.execute("""
                INSERT INTO agendamentos
                (cliente_id, servico_id, data, horario)
                VALUES (?, ?, ?, ?)
            """, (cliente_id, servico_id, data, horario))

            conexao.commit()
            flash("Agendamento realizado com sucesso!")

        except sqlite3.IntegrityError:
            conexao.rollback()
            flash("Esse horário já está ocupado ou os dados são inválidos.")

        conexao.close()
        return redirect(url_for("agendamentos"))

    lista_clientes = conexao.execute(
        "SELECT * FROM clientes ORDER BY nome"
    ).fetchall()

    lista_servicos = conexao.execute(
        "SELECT * FROM servicos ORDER BY nome"
    ).fetchall()

    lista_agendamentos = conexao.execute("""
        SELECT
            agendamentos.id,
            clientes.nome AS cliente,
            servicos.nome AS servico,
            agendamentos.data,
            agendamentos.horario
        FROM agendamentos
        JOIN clientes ON clientes.id = agendamentos.cliente_id
        JOIN servicos ON servicos.id = agendamentos.servico_id
        ORDER BY agendamentos.data, agendamentos.horario
    """).fetchall()

    conexao.close()

    return render_template(
        "agendamentos.html",
        clientes=lista_clientes,
        servicos=lista_servicos,
        agendamentos=lista_agendamentos
    )


@app.route("/agendamentos/cancelar/<int:id>", methods=["POST"])
def cancelar_agendamento(id):
    conexao = conectar()

    conexao.execute(
        "DELETE FROM agendamentos WHERE id = ?", (id,)
    )

    conexao.commit()
    conexao.close()

    flash("Agendamento cancelado.")

    return redirect(url_for("agendamentos"))


if __name__ == "__main__":
    app.run(debug=True)